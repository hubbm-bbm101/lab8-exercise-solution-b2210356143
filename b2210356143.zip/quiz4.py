# -*- coding: utf-8 -*-
"""
Created on Fri Nov 26 22:56:44 2021

@author: borak
"""
import sys
inputfile = sys.argv[1]
outputfile = sys.argv[2]

def sira(liste):
    return(liste[1])

f = open(inputfile, "a+")

liste = []
packno = []
pack = []
msgno = []
msg = []
sz = {}
f.write("\n")
f.close()
f = open(inputfile)
for line in f:
    line = line.split("\t")
    packno.append(line[0])
    packno.sort()
    packno = list(dict.fromkeys(packno))  
    msgno.append(line[1])
    msgno.sort()
    msgno = list(dict.fromkeys(msgno))
f.close()
f = open(inputfile)   

listoflist = [[] for i in range(len(packno))]    
for line in f:
    line = line.split("\t")

    for i in range(len(packno)):
        if line == ['\n']:
            print("error")
        else:
            if line[0] == packno[i]:
                listoflist[i].append(line)

f.close()
f2 = open(outputfile, "w")

for i in range(len(packno)):
      mesaj = sorted(listoflist[i], key = sira)
     
      f2.write(f"Message {i+1}\n")
      for listeler in mesaj:
          listeler[1] = "\t" + listeler[1] + "\t"
      
      for j in mesaj:
          sentence = (" ").join(j)
          f2.write(f"{sentence}")

f2.close()
